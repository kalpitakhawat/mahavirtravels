/*var checkout=document.getElementById('checkout-form');
checkout.onsubmit=submit();
function submit() {
	alert("Hello");
}
*/
function myFunction() {
	alert("Hello");
	return false;
}